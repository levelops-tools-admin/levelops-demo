import heapq
import json
import threading
from datetime import datetime
from statistics import median

import pytz
import requests
from requests.auth import HTTPBasicAuth


class PriorityEntry(object):

    def __init__(self, priority, data):
        self.data = data
        self.priority = priority

    def __lt__(self, other):
        return self.priority < other.priority


def parse_date(date_string):
    return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.%f%z")


class JANALYTICS:
    def __init__(self, url, username, password):
        self.auth = HTTPBasicAuth(username, password)
        self.url = url
        if not url.endswith("/"):
            self.url = url + "/"
        if not url.startswith("http"):
            self.url = "https://" + url
        self.headers = {
            "Accept": "application/json"
        }
        self.tickets_list = []
        self.jql = " ORDER BY updated DESC"
        self.usermap = {}
        self.report1 = {}
        self.report3 = {}
        self.count = 1000
        self.ticket_details = {}
        self.thread = None
        self.fetch_tickets = True
        self.componentmap = {}
        self.report2 = {}
        self.analysis_complete = False
        self.usermap_contains_engineering = False
        self.current_time = datetime.utcnow().replace(tzinfo=pytz.utc)

    def get_authinfo(self):
        return self.url, self.auth.username, self.auth.password

    def validate_creds(self):
        current_url = self.url + "rest/api/2/search"
        query = {
            'jql': self.jql,
            'startAt': 0,
            'maxResults': 1,
            'expand': 'changelog',
            'fields': '*all'
        }
        try:
            jira_response = requests.request(
                "GET", current_url,
                headers=self.headers,
                params=query,
                auth=self.auth)
        except Exception as e:
            print(e)
            return 400, -1
        jira_status_code = jira_response.status_code
        return jira_status_code, jira_response.json()["total"]

    def get_ticketdetails(self, ticket_id):
        if ticket_id in self.ticket_details:
            return self.ticket_details[ticket_id]
        return None

    def set_jqlandcount(self, jql, count=1000):
        self.jql = jql + " ORDER BY updated DESC"
        self.count = count
        # every new jql we need to redo fetching and analysis
        self.fetch_tickets = True
        self.tickets_list = []
        self.ticket_details = {}
        self.report1 = {}
        self.report3 = {}
        self.report2 = {}
        self.thread = None
        self.analysis_complete = False

    def get_jql(self):
        return self.jql

    def get_usermap(self):
        return self.usermap

    def get_componentmap(self):
        return self.componentmap

    def set_userorg(self, user, org):
        if user in self.usermap:
            if 'engineering' in org.lower():
                self.usermap_contains_engineering = True
            self.usermap[user] = org
            return True
        return False

    def set_componentval(self, component, val):
        if component in self.componentmap:
            self.componentmap[component] = val
            return True
        return False

    def get_bouncereport(self):
        return self.analysis_complete, self.report1

    def get_timereport(self):
        return self.analysis_complete, self.report2

    def get_resolutionreport(self):
        return self.analysis_complete, self.report3

    def get_tickets(self):
        self.tickets_list = []
        self.current_time = datetime.utcnow().replace(tzinfo=pytz.utc)
        while len(self.tickets_list) < self.count:
            jira_query = {
                'jql': self.jql,
                'startAt': len(self.tickets_list),
                'maxResults': 100,
                'expand': 'changelog',
                'fields': '*all'
            }
            jira_response = requests.request(
                "GET", self.url + "rest/api/2/search",
                headers=self.headers,
                params=jira_query,
                auth=self.auth)
            issues = jira_response.json()["issues"]
            self.tickets_list.extend(issues)
            if len(self.tickets_list) == jira_response.json()["total"]:
                break
        self.fetch_tickets = False
        return len(self.tickets_list)

    def is_analyzed(self):
        if self.analysis_complete:
            self.thread = None
        return self.analysis_complete

    def redo_analysis(self):
        if self.analysis_complete:
            self.ticket_details = {}
            self.report1 = {}
            self.report2 = {}
            self.report3 = {}
            self.analysis_complete = False
            self.thread = threading.Thread(target=self.analyze_tickets)
            self.thread.start()
            return True
        print("started thread.")
        return False

    def start_analysis(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self.analyze_tickets)
            self.thread.start()
            return True
        return False

    def analyze_tickets(self):
        if self.fetch_tickets:
            print("Starting fetching.")
            self.get_tickets()
        print("Starting analysis.")
        top_hops = []
        top_bounces = []
        hops_count_list = []
        bounce_count_list = []
        top_assigneect_tickets = []
        top_statuses = {}
        top_tickets = []
        oldest_tickets = []
        component_bounce_info = {"no_component": {"total_bounces": 0,
                                                  "num_tickets": 0,
                                                  "bounce_ct_list": [],
                                                  "max_bounce": 0,
                                                  "min_bounce": 0}}
        assignee_to_component_count = {"unassigned": {"total_tickets": 0, "no_component": 0, "assignee": "unassigned"}}
        for x in self.tickets_list:
            self.handle_ticket(x, component_bounce_info, assignee_to_component_count, bounce_count_list,
                               hops_count_list, oldest_tickets, top_tickets, top_statuses, top_hops, top_bounces,
                               top_assigneect_tickets)
        self.create_report1(component_bounce_info, bounce_count_list, hops_count_list,
                            assignee_to_component_count, top_hops, top_bounces, top_assigneect_tickets)
        # add report2
        self.create_report2(oldest_tickets, top_tickets, top_statuses)
        # cleanup report3
        self.cleanup_report3()
        print("Analysis complete.")
        self.analysis_complete = True

    def handle_ticket(self, ticket, component_bounce_info, assignee_to_component_count, bounce_count_list,
                      hops_count_list, oldest_tickets, top_tickets, top_statuses, top_hops, top_bounces,
                      top_assigneect_tickets):
        status_to_duration = {}
        assignees = {"unassigned": 0}
        num_bounces = 0
        ticket_created_date = parse_date(ticket['fields']['created'])
        times_with_assignees = []
        current_assignee = 'unassigned'
        current_status = ticket['fields']['status']['name']
        last_assignee_time = self.current_time
        resolution_date = None
        resolution_duration = None
        if ticket['fields']['resolutiondate']:
            last_assignee_time = parse_date(ticket['fields']['resolutiondate'])
            resolution_date = last_assignee_time.strftime('%Y-%m-%d')
            resolution_duration = last_assignee_time.timestamp() - ticket_created_date.timestamp()
        last_status_time = self.current_time
        if ticket['fields']['assignee']:
            current_assignee = ticket['fields']['assignee']['displayName']
            if current_assignee not in self.usermap:
                self.usermap[current_assignee] = "unknown"
            assignees[current_assignee] = 0
        if ticket['changelog']['total'] > 0:
            for log in ticket['changelog']['histories']:
                log_created_date = parse_date(log['created'])
                for item in log['items']:
                    if item['field'] == 'assignee':
                        assignee_duration = last_assignee_time.timestamp() - log_created_date.timestamp()
                        assignees[current_assignee] = assignees[current_assignee] + assignee_duration
                        last_assignee_time = log_created_date
                        times_with_assignees.append({'assignee': current_assignee,
                                                     'time': log_created_date.timestamp()})
                        current_assignee = item['fromString']
                        if current_assignee is None:
                            current_assignee = "unassigned"
                        if current_assignee not in self.usermap:
                            self.usermap[current_assignee] = "unknown"
                        if current_assignee not in assignees:
                            assignees[current_assignee] = 0
                        elif current_assignee != "unassigned":
                            num_bounces += 1
                    elif item['field'] == 'status':
                        if current_status not in status_to_duration:
                            status_to_duration[current_status] = 0
                        status_to_duration[current_status] = status_to_duration[current_status] + (
                                last_status_time.timestamp() - log_created_date.timestamp())
                        last_status_time = log_created_date
                        current_status = item['fromString']
            if current_status not in status_to_duration:
                status_to_duration[current_status] = 0
            status_to_duration[current_status] = status_to_duration[current_status] + (
                    last_status_time.timestamp() - ticket_created_date.timestamp())
            times_with_assignees.append(
                {'assignee': current_assignee,
                 'time': ticket_created_date.timestamp()})
            assignees[current_assignee] += assignees[current_assignee] + \
                                           last_assignee_time.timestamp() - ticket_created_date.timestamp()
        if ticket['fields']['assignee']:
            current_assignee = ticket['fields']['assignee']['displayName']
        attachments = []
        component_list = []
        self.handle_assignees(assignees, component_bounce_info, assignee_to_component_count, num_bounces, ticket)
        if 'components' in ticket['fields']:
            self.handle_components(component_bounce_info, num_bounces, component_list, assignees,
                                   assignee_to_component_count, ticket)
        self.append_to_report3(resolution_duration, resolution_date, component_list)
        for attachment in ticket['fields']['attachment']:
            attacher = attachment['author']['displayName']
            attachments.append({"name": attachment['filename'],
                                "attacher": attacher,
                                "time": parse_date(attachment["created"]).timestamp()})
            if attacher not in self.usermap:
                self.usermap[attacher] = "unknown"
        hops_count_list.append(len(times_with_assignees))
        bounce_count_list.append(num_bounces)
        summary = ticket["fields"]["summary"]
        # add to heaps and pop the smallest if size is greater than 25
        # oldest tickets
        heapq.heappush(oldest_tickets,
                       PriorityEntry(self.current_time.timestamp() - ticket_created_date.timestamp(),
                                     {"time": self.current_time.timestamp() - ticket_created_date.timestamp(),
                                      "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(oldest_tickets) > 25:
            heapq.heappop(oldest_tickets)
        # add assignee to heaps
        self.add_longest_assignee(assignees=assignees, top_tickets=top_tickets,
                                  summary=summary, ticket=ticket)
        # add status top to heaps
        for status, val in status_to_duration.items():
            if status not in top_statuses:
                top_statuses[status] = {"sum": 0, "list": [], "top": [], "total": 0, "status": status}
            heapq.heappush(top_statuses[status]["top"], PriorityEntry(val, {"ticket_id": ticket["key"],
                                                                            "summary": summary,
                                                                            "time": val}))
            top_statuses[status]["sum"] = top_statuses[status]["sum"] + val
            top_statuses[status]["total"] = top_statuses[status]["total"] + 1
            top_statuses[status]["list"].append(val)
            if len(top_statuses[status]["top"]) > 5:
                heapq.heappop(top_statuses[status]["top"])
        self.handle_top25_data(top_hops, top_bounces, top_assigneect_tickets, assignees,
                               num_bounces, times_with_assignees, summary, ticket)
        self.ticket_details[ticket["key"].upper()] = {"summary": summary, "bounces": num_bounces,
                                                      "current_assignee": current_assignee,
                                                      "assignees": assignees, "attachments": attachments,
                                                      "hops": times_with_assignees, "components": component_list,
                                                      "current_state": ticket['fields']['status']['name'],
                                                      "created_at": ticket_created_date.timestamp()}

    def handle_top25_data(self, top_hops, top_bounces, top_assigneect_tickets, assignees,
                          num_bounces, times_with_assignees, summary, ticket):
        heapq.heappush(top_hops,
                       PriorityEntry(len(times_with_assignees),
                                     {"hops": len(times_with_assignees), "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_hops) > 25:
            heapq.heappop(top_hops)
        heapq.heappush(top_assigneect_tickets,
                       PriorityEntry(len(assignees),
                                     {"assignees": len(assignees), "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_assigneect_tickets) > 25:
            heapq.heappop(top_assigneect_tickets)
        heapq.heappush(top_bounces,
                       PriorityEntry(num_bounces,
                                     {"bounces": num_bounces, "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_bounces) > 25:
            heapq.heappop(top_bounces)

    def handle_components(self, component_bounce_info, num_bounces, component_list, assignees,
                          assignee_to_component_count, ticket):
        for component in ticket['fields']['components']:
            component_name = component['name']
            if component_name not in self.componentmap:
                self.componentmap[component_name] = "unknown"
            if component_name not in component_bounce_info:
                component_bounce_info[component_name] = {"total_bounces": 0,
                                                         "num_tickets": 0,
                                                         "bounce_ct_list": [],
                                                         # first time its both max and min
                                                         "max_bounce": num_bounces,
                                                         "min_bounce": num_bounces}
            component_bounce_info[component_name]["total_bounces"] = \
                component_bounce_info[component_name]["total_bounces"] + num_bounces
            component_bounce_info[component_name]["bounce_ct_list"].append(num_bounces)
            component_bounce_info[component_name]["num_tickets"] = \
                component_bounce_info[component_name]["num_tickets"] + 1
            if component_bounce_info[component_name]["max_bounce"] < num_bounces:
                component_bounce_info[component_name]["max_bounce"] = num_bounces
            elif component_bounce_info[component_name]["min_bounce"] > num_bounces:
                component_bounce_info[component_name]["min_bounce"] = num_bounces
            for assignee in assignees:
                if component_name not in assignee_to_component_count[assignee]:
                    assignee_to_component_count[assignee][component_name] = 0
                assignee_to_component_count[assignee][component_name] += 1
            component_list.append(component_name)

    # calculate
    def handle_assignees(self, assignees, component_bounce_info, assignee_to_component_count, num_bounces, ticket):
        for assignee in assignees:
            if assignee not in assignee_to_component_count:
                assignee_to_component_count[assignee] = {"total_tickets": 0,
                                                         "no_component": 0,
                                                         "assignee": assignee}
            assignee_to_component_count[assignee]["total_tickets"] += 1
            if 'components' not in ticket['fields'] or len(ticket['fields']['components']) == 0:
                assignee_to_component_count[assignee]["no_component"] += 1
                component_bounce_info["no_component"]["total_bounces"] += num_bounces
                component_bounce_info["no_component"]["bounce_ct_list"].append(num_bounces)
                component_bounce_info["no_component"]["num_tickets"] += 1
                if component_bounce_info["no_component"]["max_bounce"] < num_bounces:
                    component_bounce_info["no_component"]["max_bounce"] = num_bounces
                elif component_bounce_info["no_component"]["min_bounce"] > num_bounces:
                    component_bounce_info["no_component"]["min_bounce"] = num_bounces

    # calculate assignee with longest time on ticket and also tickets that are open the longest
    def add_longest_assignee(self, assignees, top_tickets, summary, ticket):
        longest_assignee = None
        total_time = 0
        longest_time = 0
        for assignee, time in assignees.items():
            if assignee == 'unassigned':
                continue
            if self.usermap_contains_engineering:
                if 'engineering' in self.usermap[assignee].lower():
                    total_time += time
                    if time > longest_time:
                        longest_time = time
                        longest_assignee = assignee
            elif 'unknown' in self.usermap[assignee].lower():
                total_time += time
                if time > longest_time:
                    longest_time = time
                    longest_assignee = assignee
        if not longest_assignee:  # if its unassigned we dont go record it
            return top_tickets
        heapq.heappush(top_tickets, PriorityEntry(total_time,
                                                  {"longest_assignee": longest_assignee,
                                                   "ticket_id": ticket["key"],
                                                   "summary": summary,
                                                   "total_time": total_time,
                                                   "longest_assignee_time": longest_time}))
        if len(top_tickets) > 10:
            heapq.heappop(top_tickets)
        return top_tickets

    def append_to_report3(self, resolution_duration, resolution_date, components):
        if not resolution_duration or not resolution_date:
            return
        res_hours = resolution_duration / 3600
        if "resolution_dates" not in self.report3:
            self.report3["resolution_dates"] = {}
        if resolution_date not in self.report3["resolution_dates"]:
            self.report3["resolution_dates"][resolution_date] = {"list": [res_hours], "max_hours": res_hours,
                                                                 "min_hours": res_hours, "median_hours": res_hours}
        else:
            self.report3["resolution_dates"][resolution_date]["list"].append(resolution_duration / 3600)
            if self.report3["resolution_dates"][resolution_date]["max_hours"] < res_hours:
                self.report3["resolution_dates"][resolution_date]["max_hours"] = res_hours
            if self.report3["resolution_dates"][resolution_date]["min_hours"] > res_hours:
                self.report3["resolution_dates"][resolution_date]["min_hours"] = res_hours
            self.report3["resolution_dates"][resolution_date]["median_hours"] = median(
                self.report3["resolution_dates"][resolution_date]["list"])
        if "component_area" not in self.report3:
            self.report3["component_area"] = {}
        if len(components) == 0:
            if "unknown" not in self.report3["component_area"]:
                self.report3["component_area"]["unknown"] = {"list": [res_hours], "max_hours": res_hours,
                                                             "min_hours": res_hours, "median_hours": res_hours}
            else:
                self.report3["component_area"]["unknown"]["list"].append(resolution_duration / 3600)
                if self.report3["component_area"]["unknown"]["max_hours"] < res_hours:
                    self.report3["component_area"]["unknown"]["max_hours"] = res_hours
                if self.report3["component_area"]["unknown"]["min_hours"] > res_hours:
                    self.report3["component_area"]["unknown"]["min_hours"] = res_hours
                self.report3["component_area"]["unknown"]["median_hours"] = median(
                    self.report3["component_area"]["unknown"]["list"])
        for component in components:
            component_area = "unknown"
            if component in self.componentmap:
                component_area = self.componentmap[component]
            if component_area not in self.report3["component_area"]:
                self.report3["component_area"][component_area] = {"list": [res_hours], "max_hours": res_hours,
                                                                  "min_hours": res_hours, "median_hours": res_hours}
            else:
                self.report3["component_area"][component_area]["list"].append(resolution_duration / 3600)
                if self.report3["component_area"][component_area]["max_hours"] < res_hours:
                    self.report3["component_area"][component_area]["max_hours"] = res_hours
                if self.report3["component_area"][component_area]["min_hours"] > res_hours:
                    self.report3["component_area"][component_area]["min_hours"] = res_hours
                self.report3["component_area"][component_area]["median_hours"] = median(
                    self.report3["component_area"][component_area]["list"])

    def cleanup_report3(self):
        if "resolution_dates" in self.report3:
            for key, val in self.report3["resolution_dates"].items():
                del val["list"]
        else:
            self.report3["resolution_dates"] = {}
        if "component_area" in self.report3:
            for key, val in self.report3["component_area"].items():
                del val["list"]
        else:
            self.report3["component_area"] = {}

    def create_report2(self, oldest_tickets, top_tickets, top_statuses):
        self.report2["oldest_tickets"] = []
        while oldest_tickets:
            self.report2["oldest_tickets"].append(heapq.heappop(oldest_tickets).data)
        self.report2["top_tickets"] = []
        while top_tickets:
            ticket_data = heapq.heappop(top_tickets).data
            self.report2["top_tickets"].append(ticket_data)
        self.report2["statuses"] = {}
        for key, val in top_statuses.items():
            status_ticket_list = val["top"]
            val["median"] = 0
            if len(val["list"]) > 0:
                val["median"] = median(val["list"])
            del val["list"]
            val["top"] = []
            while status_ticket_list:
                val["top"].append(heapq.heappop(status_ticket_list).data)
            val["top"].reverse()
            self.report2["statuses"][key] = val
        self.report2["oldest_tickets"].reverse()
        self.report2["top_tickets"].reverse()

    def create_report1(self, component_bounce_info, bounce_count_list, hops_count_list,
                       assignee_to_component_count, top_hops, top_bounces, top_assigneect_tickets):
        self.report1 = {"hops_report": [], "bounce_report": [], "assignees_report": [],
                        "component_bounce": component_bounce_info, "assignee_to_component": [],
                        "median_bounces": median(bounce_count_list), "median_hops": median(hops_count_list),
                        "max_bounces": max(bounce_count_list), "max_hops": max(hops_count_list)}
        top_assignee_to_component = []
        for key, val in assignee_to_component_count.items():
            heapq.heappush(top_assignee_to_component, PriorityEntry(val["total_tickets"], val))
            if len(top_assignee_to_component) > 15:
                heapq.heappop(top_assignee_to_component)
        while top_assignee_to_component:
            self.report1["assignee_to_component"].append(heapq.heappop(top_assignee_to_component).data)
        while top_hops:
            self.report1["hops_report"].append(heapq.heappop(top_hops).data)
        while top_bounces:
            self.report1["bounce_report"].append(heapq.heappop(top_bounces).data)
        while top_assigneect_tickets:
            self.report1["assignees_report"].append(heapq.heappop(top_assigneect_tickets).data)
        for key, val in component_bounce_info.items():
            val["median_bounce"] = median(val["bounce_ct_list"])
            del val["bounce_ct_list"]
        self.report1["assignees_report"].reverse()
        self.report1["hops_report"].reverse()
        self.report1["bounce_report"].reverse()
        self.report1["component_bounce"] = component_bounce_info
        self.report1["assignee_to_component"].reverse()
