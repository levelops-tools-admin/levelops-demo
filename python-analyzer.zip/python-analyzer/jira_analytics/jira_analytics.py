import heapq
import threading
from datetime import datetime
from statistics import median
import collections

import pytz
import requests
from requests.auth import HTTPBasicAuth


class PriorityEntry(object):

    def __init__(self, priority, data):
        self.data = data
        self.priority = priority

    def __lt__(self, other):
        return self.priority < other.priority


def get_weight_from_percentage(val):
    if val == 0:
        return 100
    if 0 < val < 11:
        return 75
    if 11 < val < 21:
        return 55
    if 21 < val < 31:
        return 30
    if 31 < val < 41:
        return 5
    return 0


def parse_date(date_string):
    return datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%S.%f%z")


def parse_partial_date(date_string):
    return datetime.strptime(date_string, "%Y-%m-%d")


class JANALYTICS:
    def __init__(self):
        self.auth = HTTPBasicAuth(None, None)
        self.url = None
        self.headers = {
            "Accept": "application/json"
        }
        self.tickets_list = []
        self.jql = " ORDER BY updated DESC"
        self.usermap = {}
        self.report1 = {}
        self.report2 = {}
        self.report3 = {}
        self.report4 = {}
        self.report5 = {}
        self.report6 = {}
        self.count = 1000
        self.ignored_statuses = {}
        self.ticket_details = {}
        self.ticket_types = {}
        self.priorities = {}
        self.thread = None
        self.fetch_tickets = True
        self.componentmap = {}
        self.logs = collections.deque()
        self.analysis_complete = True
        self.usermap_contains_engineering = False
        self.current_time = datetime.utcnow().replace(tzinfo=pytz.utc)

    def set_authinfo(self, url, username, password):
        self.auth = HTTPBasicAuth(username, password)
        self.url = url
        if not url.endswith("/"):
            self.url = url + "/"
        if not url.startswith("http"):
            self.url = "https://" + url

    def get_authinfo(self):
        return self.url, self.auth.username, self.auth.password

    def validate_creds(self):
        current_url = self.url + "rest/api/2/search"
        query = {
            'jql': self.jql,
            'startAt': 0,
            'maxResults': 1,
            'expand': 'changelog',
            'fields': '*all'
        }
        try:
            jira_response = requests.request(
                "GET", current_url,
                headers=self.headers,
                params=query,
                auth=self.auth,
                verify=False)
            total = jira_response.json()["total"]
            if total == 0:
                self.add_logline("ERROR: Invalid credentials. No issues found.")
            return jira_response.status_code, jira_response.json()["total"]
        except Exception as e:
            self.add_logline("ERROR: Invalid credentials.")
            self.add_logline(repr(e))
            return 400, -1

    def get_ticketdetails(self, ticket_id):
        if ticket_id in self.ticket_details:
            return self.ticket_details[ticket_id]
        return None

    def add_logline(self, logline):
        self.logs.append(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ": " + logline)
        if len(self.logs) > 100:
            self.logs.popleft()

    def get_logs(self):
        return list(self.logs)

    def set_jqlandcount(self, jql, count=1000):
        self.jql = jql
        if "ORDER BY" not in self.jql:
            self.jql = self.jql + " ORDER BY updated DESC"
        self.count = count

    def get_jqlandcount(self):
        return self.jql, self.count

    def get_usermap(self):
        return self.usermap

    def get_statuses(self):
        return self.ignored_statuses

    def get_priorities(self):
        return self.priorities

    def get_tickettypes(self):
        return self.ticket_types

    def get_componentmap(self):
        return self.componentmap

    def get_fetchprogress(self):
        return {"fetched_count": len(self.tickets_list), "max_count": self.count}

    def set_statuses(self, status, ignored):
        self.ignored_statuses[status] = ignored

    def set_priorities(self, priority, val):
        if val:
            self.priorities[priority] = val

    def _internal_set_priority(self, priority):
        # only write if it doesnt already exist. values stored in hours
        if not self.priorities.get(priority):
            if priority.lower() == "highest":
                self.priorities[priority] = 24  # 1 day
            elif priority.lower() == "high":
                self.priorities[priority] = 24 * 3  # 3 days
            elif priority.lower() == "medium":
                self.priorities[priority] = 24 * 7  # 7 days
            elif priority.lower() == "low":
                self.priorities[priority] = 24 * 14  # 14 days
            elif priority.lower() == "lowest":
                self.priorities[priority] = 24 * 30  # 30 days
            else:
                self.priorities[priority] = 24 * 30  # arbitrary priority

    def set_tickettypes(self, ticket_type, val):
        self.ticket_types[ticket_type] = val

    def set_userorg(self, user, org):
        if 'engineering' in org.lower():
            self.usermap_contains_engineering = True
        self.usermap[user] = org

    def set_componentval(self, component, val):
        self.componentmap[component] = val

    def get_bouncereport(self):
        return self.analysis_complete, self.report1

    def get_timereport(self):
        return self.analysis_complete, self.report2

    def get_resolutionreport(self):
        return self.analysis_complete, self.report3

    def get_linkreport(self):
        return self.analysis_complete, self.report4

    def get_slareport(self):
        return self.analysis_complete, self.report5

    def get_hygienereport(self):
        return self.analysis_complete, self.report6

    def get_tickets(self):
        try:
            self.tickets_list = []
            self.current_time = datetime.utcnow().replace(tzinfo=pytz.utc)
            while len(self.tickets_list) < self.count:
                jira_query = {
                    'jql': self.jql,
                    'startAt': len(self.tickets_list),
                    'maxResults': 100,
                    'expand': 'changelog',
                    'fields': '*all'
                }
                jira_response = requests.request(
                    "GET", self.url + "rest/api/2/search",
                    headers=self.headers,
                    params=jira_query,
                    auth=self.auth,
                    verify=False)
                issues = jira_response.json()["issues"]
                self.tickets_list.extend(issues)
                if len(self.tickets_list) == jira_response.json()["total"]:
                    break
            self.count = len(self.tickets_list)
            self.fetch_tickets = False
        except Exception as e:
            self.add_logline("Error fetching tickets: " + repr(e))
        return len(self.tickets_list)

    def is_analyzed(self):
        if self.analysis_complete:
            self.thread = None
        return self.analysis_complete

    def redo_analysis(self):
        if self.analysis_complete:
            self.ticket_details = {}
            self.report1 = {}
            self.report2 = {}
            self.report3 = {}
            self.report4 = {}
            self.report5 = {}
            self.report6 = {}
            self.analysis_complete = False
            self.thread = threading.Thread(target=self.analyze_tickets)
            self.thread.start()
            return True
        return False

    def start_refetchandanalysis(self):
        if self.analysis_complete:
            # every new jql we need to redo fetching and analysis
            self.fetch_tickets = True
            self.tickets_list = []
            self.ticket_details = {}
            self.report1 = {}
            self.report2 = {}
            self.report3 = {}
            self.report4 = {}
            self.report5 = {}
            self.report6 = {}
            self.thread = None
            self.analysis_complete = False
            self.thread = threading.Thread(target=self.analyze_tickets)
            self.thread.start()
            return True
        return False

    def analyze_tickets(self):
        self.add_logline("Started task.")
        if self.fetch_tickets:
            self.add_logline("Starting ticket fetching.")
            self.get_tickets()
        self.add_logline("Starting analysis.")
        top_hops = []
        top_bounces = []
        hops_count_list = []
        bounce_count_list = []
        top_assigneect_tickets = []
        top_tickets = {"no_filter": [], "priority_filter": {}, "type_filter": {}}
        top_statuses_by_time_spent = {"no_filter": {}, "priority_filter": {}, "type_filter": {}}
        component_bounce_info = {"no_component": {"total_bounces": 0, "num_tickets": 0, "bounce_ct_list": [],
                                                  "max_bounce": 0, "min_bounce": 0}}
        priority_bounce_info = {}
        type_bounce_info = {}
        assignee_to_component_count = {"unassigned": {"total_tickets": 0, "no_component": 0, "assignee": "unassigned"}}
        assignee_to_priority_count = {"unassigned": {"total_tickets": 0, "no_component": 0, "assignee": "unassigned"}}
        assignee_to_type_count = {"unassigned": {"total_tickets": 0, "no_component": 0, "assignee": "unassigned"}}
        i = 0
        for x in self.tickets_list:
            if i % 100 == 0:
                self.add_logline("Analyzing ticket num: " + str(i))
            i = i + 1
            self.handle_ticket(x, component_bounce_info, priority_bounce_info, type_bounce_info,
                               assignee_to_component_count, assignee_to_priority_count, assignee_to_type_count,
                               bounce_count_list, hops_count_list, top_tickets, top_statuses_by_time_spent, top_hops,
                               top_bounces, top_assigneect_tickets)
        self.create_report1(component_bounce_info, priority_bounce_info, type_bounce_info,
                            assignee_to_component_count, assignee_to_priority_count, assignee_to_type_count,
                            bounce_count_list, hops_count_list, top_hops, top_bounces, top_assigneect_tickets)
        # add report2
        self.create_report2(top_tickets, top_statuses_by_time_spent)
        # final cleanup of some reports
        self.cleanup_report3()
        self.cleanup_report4()
        self.cleanup_report5()
        self.cleanup_report6()
        # done!
        self.add_logline("Analysis complete.")
        self.analysis_complete = True

    def handle_ticket(self, ticket, component_bounce_info, priority_bounce_info, type_bounce_info,
                      assignee_to_component_count, assignee_to_priority_count, assignee_to_type_count,
                      bounce_count_list, hops_count_list, top_tickets, top_statuses_by_time_spent,
                      top_hops, top_bounces, top_assigneect_tickets):
        try:
            status_to_duration = {}
            assignees = {"unassigned": 0}
            num_bounces = 0
            ticket_created_date = parse_date(ticket['fields']['created'])
            ticket_updated_date = parse_date(ticket['fields']['updated'])
            times_with_assignees = []
            issue_links = {"_total_links": 0}
            reporter = 'unassigned'
            current_assignee = 'unassigned'
            current_status = ticket['fields']['status']['name']
            last_assignee_time = self.current_time
            last_status_time = self.current_time
            first_comment_time = None
            first_attachment_time = None
            resolution_time = None
            resolution_date = None
            resolution_duration = None
            due_at_time = None
            if ticket['fields']['duedate']:
                due_at_time = parse_partial_date(ticket['fields']['duedate'])  # this usually only contains day
            for link in ticket['fields']['issuelinks']:
                link_type = link['type']['name']
                linked_issues = []  # just incase there are multiple issues in the same link
                if "outwardIssue" in link:
                    linked_issues.append(link['outwardIssue']['key'])
                if "inwardIssue" in link:
                    linked_issues.append(link['inwardIssue']['key'])
                if link_type not in issue_links:
                    issue_links[link_type] = {"count": 0, "list": []}
                issue_links[link_type]['count'] = issue_links[link_type]['count'] + len(linked_issues)
                issue_links[link_type]['list'].extend(linked_issues)
                issue_links["_total_links"] = issue_links["_total_links"] + len(linked_issues)
            if ticket['fields']['resolutiondate']:
                resolution_time = parse_date(ticket['fields']['resolutiondate'])
                last_status_time = resolution_time
                last_assignee_time = last_status_time
                resolution_date = resolution_time.strftime('%Y-%m-%d')
                resolution_duration = resolution_time.timestamp() - ticket_created_date.timestamp()
            if ticket['fields']['assignee']:
                current_assignee = ticket['fields']['assignee']['displayName']
                if current_assignee not in self.usermap:
                    self.usermap[current_assignee] = "unknown"
                assignees[current_assignee] = 0
            if ticket['fields']['reporter']:
                reporter = ticket['fields']['reporter']['displayName']
                if reporter not in self.usermap:
                    self.usermap[reporter] = "unknown"
                assignees[reporter] = 0
            assignee_iterator = current_assignee
            status_iterator = current_status
            if ticket['changelog']['total'] > 0:
                for log in ticket['changelog']['histories']:
                    log_created_date = parse_date(log['created'])
                    for item in log['items']:
                        if item['field'].lower() == 'assignee':
                            assignee_duration = last_assignee_time.timestamp() - log_created_date.timestamp()
                            assignees[assignee_iterator] = assignees[assignee_iterator] + assignee_duration
                            last_assignee_time = log_created_date
                            times_with_assignees.append({'assignee': assignee_iterator,
                                                         'time': log_created_date.timestamp()})
                            assignee_iterator = item['fromString']
                            if assignee_iterator is None:
                                assignee_iterator = "unassigned"
                            if assignee_iterator not in self.usermap:
                                self.usermap[assignee_iterator] = "unknown"
                            if assignee_iterator not in assignees:
                                assignees[assignee_iterator] = 0
                            elif assignee_iterator != "unassigned":
                                num_bounces += 1
                        elif item['field'].lower() == 'status':
                            if status_iterator not in self.ignored_statuses:
                                self.ignored_statuses[status_iterator] = False
                            if status_iterator not in status_to_duration:
                                status_to_duration[status_iterator] = 0
                            # max is necessary because we have noticed that sometimes we get negative values?
                            status_to_duration[status_iterator] += max((
                                    last_status_time.timestamp() - log_created_date.timestamp()), 0)
                            last_status_time = log_created_date
                            status_iterator = item['fromString']
                        elif item['field'].lower() == 'comment':
                            first_comment_time = log_created_date
            if status_iterator not in self.ignored_statuses:
                self.ignored_statuses[status_iterator] = False
            if status_iterator not in status_to_duration:
                status_to_duration[status_iterator] = 0
            status_to_duration[status_iterator] += max((
                    last_status_time.timestamp() - ticket_created_date.timestamp()), 0)
            times_with_assignees.append(
                {'assignee': assignee_iterator,
                 'time': ticket_created_date.timestamp()})
            assignees[assignee_iterator] += assignees[assignee_iterator] + \
                                            last_assignee_time.timestamp() - ticket_created_date.timestamp()
            attachments = []
            summary = ticket["fields"]["summary"]
            ticket_type = self.handle_type(type_bounce_info, num_bounces, ticket)
            priority = self.handle_priority(priority_bounce_info, num_bounces, ticket)
            self._internal_set_priority(priority)
            self.set_tickettypes(ticket_type, None)
            self.handle_assignee(current_assignee, assignee_to_component_count, assignee_to_priority_count,
                                 assignee_to_type_count, ticket_type, priority, ticket)
            component_list = self.handle_components(component_bounce_info, num_bounces, current_assignee,
                                                    assignee_to_component_count, ticket)
            self.append_to_report5(resolution_time, first_comment_time, ticket_created_date, priority, component_list)
            self.append_to_report3(resolution_duration, ticket_type, priority, resolution_date, component_list)
            for attachment in ticket['fields']['attachment']:
                attacher = attachment['author']['displayName']
                attachment_time = parse_date(attachment["created"])
                if not first_attachment_time or first_attachment_time.timestamp() > attachment_time.timestamp():
                    first_attachment_time = attachment_time
                attachments.append({"name": attachment['filename'],
                                    "attacher": attacher,
                                    "time": parse_date(attachment["created"]).timestamp()})
                if attacher not in self.usermap:
                    self.usermap[attacher] = "unknown"
            self.append_to_report6(current_assignee, component_list, priority, ticket['fields']['description'],
                                   reporter, self.current_time, due_at_time, ticket_created_date, ticket_updated_date,
                                   ticket_type, current_status, first_attachment_time, ticket["key"].upper())
            hops_count_list.append(len(times_with_assignees))
            bounce_count_list.append(num_bounces)

            # add to heaps and pop the smallest if size is greater than 25
            if ticket['fields']['status']['name'] not in self.ignored_statuses or \
                    self.ignored_statuses[ticket['fields']['status']['name']] is False:
                # add top ticket stuff only if not in ignored status currently
                self.calculate_top_ticket(assignees, top_tickets, priority, ticket_type, summary, ticket)

            self.handle_top25_data(top_hops, top_bounces, top_assigneect_tickets, assignees,
                                   num_bounces, times_with_assignees, summary, ticket)

            self.handle_top_by_times(top_statuses_by_time_spent, status_to_duration, ticket)

            self.update_link_report(ticket, summary, issue_links)

            self.ticket_details[ticket["key"].upper()] = {"summary": summary, "bounces": num_bounces,
                                                          "current_assignee": current_assignee,
                                                          "assignees": assignees, "attachments": attachments,
                                                          "hops": times_with_assignees, "components": component_list,
                                                          "current_state": ticket['fields']['status']['name'],
                                                          "created_at": ticket_created_date.timestamp(),
                                                          "linking_details": issue_links}
        except Exception as e:
            self.add_logline("Error analyzing a ticket: " + repr(e))

    def handle_top_by_times(self, top_statuses_by_time_spent, status_to_duration, ticket):
        prio = ticket["fields"]["priority"]["name"]
        task_type = ticket["fields"]["issuetype"]["name"]
        # add status to heap for top statuses, only if the status is not ignored
        for status, val in status_to_duration.items():
            if status in self.ignored_statuses and self.ignored_statuses[status] is True:
                continue
            if status not in top_statuses_by_time_spent["no_filter"]:
                top_statuses_by_time_spent["no_filter"][status] = {"sum": 0, "list": [], "top": [], "total": 0}
            if prio not in top_statuses_by_time_spent["priority_filter"]:
                top_statuses_by_time_spent["priority_filter"][prio] = {}
            if status not in top_statuses_by_time_spent["priority_filter"][prio]:
                top_statuses_by_time_spent["priority_filter"][prio][status] = {"sum": 0, "list": [], "top": [],
                                                                               "total": 0}
            if task_type not in top_statuses_by_time_spent["type_filter"]:
                top_statuses_by_time_spent["type_filter"][task_type] = {}
            if status not in top_statuses_by_time_spent["type_filter"][task_type]:
                top_statuses_by_time_spent["type_filter"][task_type][status] = {"sum": 0, "list": [], "top": [],
                                                                                "total": 0}
            # top level
            self.top_ticket_calculation(top_statuses_by_time_spent["no_filter"][status], prio, task_type, val, ticket)
            # prio
            self.top_ticket_calculation(top_statuses_by_time_spent["priority_filter"][prio][status], prio, task_type,
                                        val, ticket)
            # tasktype
            self.top_ticket_calculation(top_statuses_by_time_spent["type_filter"][task_type][status], prio, task_type,
                                        val, ticket)

    def update_link_report(self, ticket, summary, issue_links):
        if "total_links" not in self.report4:
            self.report4["total_links"] = []
        if "blocks_links" not in self.report4:
            self.report4["blocks_links"] = []
        if "duplicate_links" not in self.report4:
            self.report4["duplicate_links"] = []
        heapq.heappush(self.report4["total_links"],
                       PriorityEntry(issue_links["_total_links"],
                                     {"count": issue_links["_total_links"],
                                      "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(self.report4["total_links"]) > 25:
            heapq.heappop(self.report4["total_links"])
        # if blocks links exist
        if "Blocks" in issue_links:
            heapq.heappush(self.report4["blocks_links"],
                           PriorityEntry(issue_links["Blocks"]["count"],
                                         {"count": issue_links["Blocks"]["count"],
                                          "ticket_id": ticket["key"],
                                          "summary": summary}))
            if len(self.report4["blocks_links"]) > 25:
                heapq.heappop(self.report4["blocks_links"])
        # if duplicate links exist
        if "Duplicate" in issue_links:
            heapq.heappush(self.report4["duplicate_links"],
                           PriorityEntry(issue_links["Duplicate"]["count"],
                                         {"count": issue_links["Duplicate"]["count"],
                                          "ticket_id": ticket["key"],
                                          "summary": summary}))
            if len(self.report4["duplicate_links"]) > 25:
                heapq.heappop(self.report4["duplicate_links"])

    def handle_components(self, component_bounce_info, num_bounces, current_assignee, assignee_to_component_count,
                          ticket):
        component_list = []
        if 'components' not in ticket['fields'] or len(ticket['fields']['components']) == 0:
            component_bounce_info["no_component"]["total_bounces"] += num_bounces
            component_bounce_info["no_component"]["bounce_ct_list"].append(num_bounces)
            component_bounce_info["no_component"]["num_tickets"] += 1
            if component_bounce_info["no_component"]["max_bounce"] < num_bounces:
                component_bounce_info["no_component"]["max_bounce"] = num_bounces
            elif component_bounce_info["no_component"]["min_bounce"] > num_bounces:
                component_bounce_info["no_component"]["min_bounce"] = num_bounces
            return []
        for component in ticket['fields']['components']:
            component_name = component['name']
            if component_name not in self.componentmap:
                self.componentmap[component_name] = component_name
            if component_name not in component_bounce_info:
                component_bounce_info[component_name] = {"total_bounces": 0, "num_tickets": 0, "bounce_ct_list": [],
                                                         # first time its both max and min
                                                         "max_bounce": num_bounces, "min_bounce": num_bounces}
            component_bounce_info[component_name]["total_bounces"] = \
                component_bounce_info[component_name]["total_bounces"] + num_bounces
            component_bounce_info[component_name]["bounce_ct_list"].append(num_bounces)
            component_bounce_info[component_name]["num_tickets"] = \
                component_bounce_info[component_name]["num_tickets"] + 1
            if component_bounce_info[component_name]["max_bounce"] < num_bounces:
                component_bounce_info[component_name]["max_bounce"] = num_bounces
            elif component_bounce_info[component_name]["min_bounce"] > num_bounces:
                component_bounce_info[component_name]["min_bounce"] = num_bounces
            if component_name not in assignee_to_component_count[current_assignee]:
                assignee_to_component_count[current_assignee][component_name] = 0
            assignee_to_component_count[current_assignee][component_name] += 1
            component_list.append(component_name)
        return component_list

    def append_to_report6(self, assignee, component_list, priority, description, reporter, current_time, due_at_time,
                          ticket_created_time, ticket_updated_time, ticket_type, status, first_attachment_time, key):
        total_tickets_ct = len(self.tickets_list)
        if not self.report6:
            self.report6 = {"jira_hygiene_score": 0,
                            "unassigned_issues": {"total": 0, "list": []},
                            "bugs_without_due_date": {"total": 0, "list": []},
                            "epics_or_stories_without_due_date": {"total": 0, "list": []},
                            "bugs_without_or_late_attachments": {"total": 0, "list": []},
                            "issues_without_components": {"total": 0, "list": []},
                            "bugs_with_no_activity_in_1year": {"total": 0, "list": []},
                            "bugs_with_description_under_10words": {"total": 0, "list": []},
                            "total_bugs": 0, "total_epics_or_stories": 0}
        if ticket_type.lower() == "bug":
            self.report6["total_bugs"] += 1
        if ticket_type.lower() == "epic" or ticket_type.lower() == "story":
            self.report6["total_epics_or_stories"] += 1
        ticket_object = {"component_list": component_list, "priority": priority, "reporter": reporter, "key": key,
                         "created_at": ticket_created_time.timestamp(), "ticket_type": ticket_type, "state": status}
        hygiene_calculator = 0

        x = self.report6["unassigned_issues"]
        if not assignee or assignee == "unassigned":
            x["total"] += 1
            x["list"].append(ticket_object)
        hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / total_tickets_ct) * .2

        x = self.report6["bugs_without_due_date"]
        if not due_at_time and ticket_type.lower() == "bug":
            x["total"] += 1
            x["list"].append(ticket_object)
        if self.report6["total_bugs"] > 0:  # prevent division by 0
            hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / self.report6["total_bugs"]) * .15

        x = self.report6["epics_or_stories_without_due_date"]
        if not due_at_time and (ticket_type.lower() == "epic" or ticket_type.lower() == "story"):
            x["total"] += 1
            x["list"].append(ticket_object)
        if self.report6["total_epics_or_stories"] > 0:  # prevent division by 0
            hygiene_calculator += get_weight_from_percentage(
                (x["total"] * 100) / self.report6["total_epics_or_stories"]) * .15

        x = self.report6["issues_without_components"]
        if not component_list or len(component_list) == 0:
            x["total"] += 1
            x["list"].append(ticket_object)
        hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / total_tickets_ct) * .2

        x = self.report6["bugs_without_or_late_attachments"]
        if not first_attachment_time or ((first_attachment_time.timestamp() - ticket_created_time.timestamp()) > 86400):
            x["total"] += 1
            x["list"].append(ticket_object)
        hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / total_tickets_ct) * .02

        x = self.report6["bugs_with_no_activity_in_1year"]
        if ticket_type.lower() == "bug" \
                and (current_time.timestamp() - ticket_updated_time.timestamp() > 365 * 86400):
            x["total"] += 1
            x["list"].append(ticket_object)
        hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / total_tickets_ct) * .2

        x = self.report6["bugs_with_description_under_10words"]
        if ticket_type.lower() == "bug" \
                and (not description or not description.strip() or len(description.split(" ")) <= 10):
            x["total"] += 1
            x["list"].append(ticket_object)
        hygiene_calculator += get_weight_from_percentage((x["total"] * 100) / total_tickets_ct) * .08
        self.report6["jira_hygiene_score"] = hygiene_calculator

    def append_to_report5(self, resolution_time, first_comment_time, ticket_created_time, priority, components):
        time_to_first_comment = self.current_time.timestamp() - ticket_created_time.timestamp()  # if not specified
        resolution_duration = self.current_time.timestamp() - ticket_created_time.timestamp()  # if not specified
        if first_comment_time:  # if no comment yet then we take current time to check sla
            time_to_first_comment = (first_comment_time.timestamp() - ticket_created_time.timestamp()) / 3600
        if resolution_time:  # we are over the resolution time
            resolution_duration = (resolution_time.timestamp() - ticket_created_time.timestamp()) / 3600
        if not self.report5:
            self.report5 = {"response_miss": {}, "resolution_miss": {}}
        for component in components:
            if component not in self.report5["response_miss"]:
                self.report5["response_miss"][component] = {"ticket_count": 0, "sum_hours": 0, "list": []}
                self.report5["resolution_miss"][component] = {"ticket_count": 0, "sum_hours": 0, "list": []}
            if self.priorities[priority] <= resolution_duration:  # hours matching
                self.report5["resolution_miss"][component]["ticket_count"] += 1
                self.report5["resolution_miss"][component]["sum_hours"] += resolution_duration
                self.report5["resolution_miss"][component]["list"].append(resolution_duration)
            if self.priorities[priority] <= time_to_first_comment:  # hours matching
                self.report5["response_miss"][component]["ticket_count"] += 1
                self.report5["response_miss"][component]["sum_hours"] += time_to_first_comment
                self.report5["response_miss"][component]["list"].append(time_to_first_comment)

    # calculate assignee with longest time on ticket and also tickets that are open the longest
    def calculate_top_ticket(self, assignees, top_tickets, priority, ticket_type, summary, ticket):
        longest_assignee = None
        total_time = 0
        longest_time = 0
        for assignee, time in assignees.items():
            if assignee == 'unassigned':
                continue
            if self.usermap_contains_engineering:
                if 'engineering' in self.usermap[assignee].lower():
                    total_time += time
                    if time > longest_time:
                        longest_time = time
                        longest_assignee = assignee
            elif 'unknown' in self.usermap[assignee].lower():
                total_time += time
                if time > longest_time:
                    longest_time = time
                    longest_assignee = assignee
        if not longest_assignee:  # if its unassigned we dont record it
            return
        heapq.heappush(top_tickets["no_filter"], PriorityEntry(total_time,
                                                               {"longest_assignee": longest_assignee,
                                                                "ticket_id": ticket["key"],
                                                                "summary": summary,
                                                                "priority": priority,
                                                                "type": ticket_type,
                                                                "total_time": total_time,
                                                                "longest_assignee_time": longest_time}))
        if len(top_tickets["no_filter"]) > 10:
            heapq.heappop(top_tickets["no_filter"])
        # priority map
        if priority not in top_tickets["priority_filter"]:
            top_tickets["priority_filter"][priority] = []
        heapq.heappush(top_tickets["priority_filter"][priority], PriorityEntry(total_time,
                                                                               {"longest_assignee": longest_assignee,
                                                                                "ticket_id": ticket["key"],
                                                                                "summary": summary,
                                                                                "priority": priority,
                                                                                "type": ticket_type,
                                                                                "total_time": total_time,
                                                                                "longest_assignee_time": longest_time}))
        if len(top_tickets["priority_filter"][priority]) > 10:
            heapq.heappop(top_tickets["priority_filter"][priority])
        # type map
        if ticket_type not in top_tickets["type_filter"]:
            top_tickets["type_filter"][ticket_type] = []
        heapq.heappush(top_tickets["type_filter"][ticket_type], PriorityEntry(total_time,
                                                                              {"longest_assignee": longest_assignee,
                                                                               "ticket_id": ticket["key"],
                                                                               "summary": summary,
                                                                               "priority": priority,
                                                                               "type": ticket_type,
                                                                               "total_time": total_time,
                                                                               "longest_assignee_time": longest_time}))
        if len(top_tickets["type_filter"][ticket_type]) > 10:
            heapq.heappop(top_tickets["type_filter"][ticket_type])
        return

    def append_to_report3(self, resolution_duration, ticket_type, priority, resolution_date, components):
        if not resolution_duration or not resolution_date:
            return
        res_hours = resolution_duration / 3600
        if "ticket_types_by_resolution_time" not in self.report3:
            self.report3["ticket_types_by_resolution_time"] = {}
        if ticket_type not in self.report3["ticket_types_by_resolution_time"]:
            self.report3["ticket_types_by_resolution_time"][ticket_type] = {"list": [], "total": 0,
                                                                            "type": ticket_type}
        self.report3["ticket_types_by_resolution_time"][ticket_type]["total"] = \
            self.report3["ticket_types_by_resolution_time"][ticket_type]["total"] + 1
        # this list is used to get the median and max values
        self.report3["ticket_types_by_resolution_time"][ticket_type]["list"].append(res_hours)

        if "priorities_by_resolution_time" not in self.report3:
            self.report3["priorities_by_resolution_time"] = {}
        if priority not in self.report3["priorities_by_resolution_time"]:
            self.report3["priorities_by_resolution_time"][priority] = {"list": [], "total": 0,
                                                                       "priority": priority}

        self.report3["priorities_by_resolution_time"][priority]["total"] = \
            self.report3["priorities_by_resolution_time"][priority]["total"] + 1
        # this list is used to get the median and max values
        self.report3["priorities_by_resolution_time"][priority]["list"].append(res_hours)

        if "resolution_dates" not in self.report3:
            self.report3["resolution_dates"] = {}
        if resolution_date not in self.report3["resolution_dates"]:
            self.report3["resolution_dates"][resolution_date] = {"list": [res_hours], "max_hours": res_hours,
                                                                 "min_hours": res_hours, "median_hours": res_hours}
        else:
            self.report3["resolution_dates"][resolution_date]["list"].append(resolution_duration / 3600)
            if self.report3["resolution_dates"][resolution_date]["max_hours"] < res_hours:
                self.report3["resolution_dates"][resolution_date]["max_hours"] = res_hours
            if self.report3["resolution_dates"][resolution_date]["min_hours"] > res_hours:
                self.report3["resolution_dates"][resolution_date]["min_hours"] = res_hours
            self.report3["resolution_dates"][resolution_date]["median_hours"] = median(
                self.report3["resolution_dates"][resolution_date]["list"])
        if "component_area" not in self.report3:
            self.report3["component_area"] = {}
        if len(components) == 0:
            if "unknown" not in self.report3["component_area"]:
                self.report3["component_area"]["unknown"] = {"list": [res_hours], "max_hours": res_hours,
                                                             "min_hours": res_hours, "median_hours": res_hours}
            else:
                self.report3["component_area"]["unknown"]["list"].append(resolution_duration / 3600)
                if self.report3["component_area"]["unknown"]["max_hours"] < res_hours:
                    self.report3["component_area"]["unknown"]["max_hours"] = res_hours
                if self.report3["component_area"]["unknown"]["min_hours"] > res_hours:
                    self.report3["component_area"]["unknown"]["min_hours"] = res_hours
                self.report3["component_area"]["unknown"]["median_hours"] = median(
                    self.report3["component_area"]["unknown"]["list"])
        for component in components:
            component_area = "unknown"
            if component in self.componentmap:
                component_area = self.componentmap[component]
            if component_area not in self.report3["component_area"]:
                self.report3["component_area"][component_area] = {"list": [res_hours], "max_hours": res_hours,
                                                                  "min_hours": res_hours, "median_hours": res_hours}
            else:
                self.report3["component_area"][component_area]["list"].append(resolution_duration / 3600)
                if self.report3["component_area"][component_area]["max_hours"] < res_hours:
                    self.report3["component_area"][component_area]["max_hours"] = res_hours
                if self.report3["component_area"][component_area]["min_hours"] > res_hours:
                    self.report3["component_area"][component_area]["min_hours"] = res_hours
                self.report3["component_area"][component_area]["median_hours"] = median(
                    self.report3["component_area"][component_area]["list"])

    def cleanup_report6(self):
        del self.report6["total_bugs"]
        del self.report6["total_epics_or_stories"]

    def cleanup_report5(self):
        for key, val in self.report5["response_miss"].items():
            val["min_hours"], val["max_hours"], val["median_hours"] = self.get_min_max_median(val["list"])
            del val["list"]
            self.report5["response_miss"][key] = val
        for key, val in self.report5["resolution_miss"].items():
            val["min_hours"], val["max_hours"], val["median_hours"] = self.get_min_max_median(val["list"])
            del val["list"]
            self.report5["resolution_miss"][key] = val

    def cleanup_report4(self):
        links = []
        while self.report4["total_links"]:
            links.append(heapq.heappop(self.report4["total_links"]).data)
        links.reverse()
        self.report4["total_links"] = links
        links = []
        while self.report4["blocks_links"]:
            links.append(heapq.heappop(self.report4["blocks_links"]).data)
        links.reverse()
        self.report4["blocks_links"] = links
        links = []
        while self.report4["duplicate_links"]:
            links.append(heapq.heappop(self.report4["duplicate_links"]).data)
        links.reverse()
        self.report4["duplicate_links"] = links

    def cleanup_report3(self):
        try:
            if "resolution_dates" in self.report3:
                for key, val in self.report3["resolution_dates"].items():
                    del val["list"]
            else:
                self.report3["resolution_dates"] = {}
            if "component_area" in self.report3:
                for key, val in self.report3["component_area"].items():
                    del val["list"]
            else:
                self.report3["component_area"] = {}
            priorities_by_resolution_time = self.report3["priorities_by_resolution_time"]
            for key, val in priorities_by_resolution_time.items():
                val["min_hours"], val["max_hours"], val["median_hours"] = self.get_min_max_median(val["list"])
                del val["list"]
            ticket_types_by_resolution_time = self.report3["ticket_types_by_resolution_time"]
            for key, val in ticket_types_by_resolution_time.items():
                val["min_hours"], val["max_hours"], val["median_hours"] = self.get_min_max_median(val["list"])
                del val["list"]
        except Exception as e:
            self.add_logline("Error creating report 3: " + repr(e))

    def create_report2(self, top_tickets, top_statuses_by_time_spent):
        try:
            self.report2["top_tickets"] = {"no_filter": [], "priority_filter": {}, "type_filter": {}}
            while top_tickets["no_filter"]:
                ticket_data = heapq.heappop(top_tickets["no_filter"]).data
                self.report2["top_tickets"]["no_filter"].append(ticket_data)
            self.report2["top_tickets"]["no_filter"].reverse()
            for key, val in top_tickets["priority_filter"].items():
                if key not in self.report2["top_tickets"]["priority_filter"]:
                    self.report2["top_tickets"]["priority_filter"][key] = []
                while val:
                    ticket_data = heapq.heappop(val).data
                    self.report2["top_tickets"]["priority_filter"][key].append(ticket_data)
                self.report2["top_tickets"]["priority_filter"][key].reverse()
            for key, val in top_tickets["type_filter"].items():
                if key not in self.report2["top_tickets"]["type_filter"]:
                    self.report2["top_tickets"]["type_filter"][key] = []
                while val:
                    ticket_data = heapq.heappop(val).data
                    self.report2["top_tickets"]["type_filter"][key].append(ticket_data)
                self.report2["top_tickets"]["type_filter"][key].reverse()
            self.report2["statuses"] = {"no_filter": {}, "priority_filter": {}, "type_filter": {}}
            for key, val in top_statuses_by_time_spent["no_filter"].items():
                status_ticket_list = val["top"]
                a, b, val["median"] = self.get_min_max_median(val["list"])
                del val["list"]
                val["top"] = []
                while status_ticket_list:
                    val["top"].append(heapq.heappop(status_ticket_list).data)
                val["top"].reverse()
                self.report2["statuses"]["no_filter"][key] = val
            for key, val in top_statuses_by_time_spent["priority_filter"].items():
                for k1, v1 in val.items():
                    status_ticket_list = v1["top"]
                    a, b, v1["median"] = self.get_min_max_median(v1["list"])
                    del v1["list"]
                    v1["top"] = []
                    while status_ticket_list:
                        v1["top"].append(heapq.heappop(status_ticket_list).data)
                    v1["top"].reverse()
                    if key not in self.report2["statuses"]["priority_filter"]:
                        self.report2["statuses"]["priority_filter"][key] = {}
                    self.report2["statuses"]["priority_filter"][key][k1] = v1
            for key, val in top_statuses_by_time_spent["type_filter"].items():
                for k1, v1 in val.items():
                    status_ticket_list = v1["top"]
                    a, b, v1["median"] = self.get_min_max_median(v1["list"])
                    del v1["list"]
                    v1["top"] = []
                    while status_ticket_list:
                        v1["top"].append(heapq.heappop(status_ticket_list).data)
                    v1["top"].reverse()
                    if key not in self.report2["statuses"]["type_filter"]:
                        self.report2["statuses"]["type_filter"][key] = {}
                    self.report2["statuses"]["type_filter"][key][k1] = v1
        except Exception as e:
            self.add_logline("Error creating report 2: " + repr(e))

    def create_report1(self, component_bounce_info, priority_bounce_info, type_bounce_info, assignee_to_component_count,
                       assignee_to_priority_count, assignee_to_type_count, bounce_count_list, hops_count_list,
                       top_hops, top_bounces, top_assigneect_tickets):
        try:
            self.report1 = {"hops_report": [], "bounce_report": [], "assignees_report": [], "links_report": [],
                            "component_bounce": {}, "priority_bounce": {}, "assignee_to_component": [],
                            "assignee_to_priority": [], "assignee_to_type": [],
                            "median_bounces": median(bounce_count_list), "median_hops": median(hops_count_list),
                            "max_bounces": max(bounce_count_list), "max_hops": max(hops_count_list)}
            top_assignee_to_component = []
            for key, val in assignee_to_component_count.items():
                heapq.heappush(top_assignee_to_component, PriorityEntry(val["total_tickets"], val))
                if len(top_assignee_to_component) > 15:
                    heapq.heappop(top_assignee_to_component)
            top_assignee_to_prio = []
            for key, val in assignee_to_priority_count.items():
                heapq.heappush(top_assignee_to_prio, PriorityEntry(val["total_tickets"], val))
                if len(top_assignee_to_prio) > 15:
                    heapq.heappop(top_assignee_to_prio)
            top_assignee_to_type = []
            for key, val in assignee_to_type_count.items():
                heapq.heappush(top_assignee_to_type, PriorityEntry(val["total_tickets"], val))
                if len(top_assignee_to_type) > 15:
                    heapq.heappop(top_assignee_to_type)
            while top_assignee_to_component:
                self.report1["assignee_to_component"].append(heapq.heappop(top_assignee_to_component).data)
            self.report1["assignee_to_component"].reverse()
            while top_assignee_to_prio:
                self.report1["assignee_to_priority"].append(heapq.heappop(top_assignee_to_prio).data)
            self.report1["assignee_to_priority"].reverse()
            while top_assignee_to_type:
                self.report1["assignee_to_type"].append(heapq.heappop(top_assignee_to_type).data)
            self.report1["assignee_to_type"].reverse()
            while top_hops:
                self.report1["hops_report"].append(heapq.heappop(top_hops).data)
            self.report1["hops_report"].reverse()
            while top_bounces:
                self.report1["bounce_report"].append(heapq.heappop(top_bounces).data)
            self.report1["bounce_report"].reverse()
            while top_assigneect_tickets:
                self.report1["assignees_report"].append(heapq.heappop(top_assigneect_tickets).data)
            self.report1["assignees_report"].reverse()
            for key, val in priority_bounce_info.items():
                if len(val["bounce_ct_list"]) > 0:
                    val["median_bounce"] = median(val["bounce_ct_list"])
                del val["bounce_ct_list"]
            self.report1["priority_bounce"] = priority_bounce_info
            for key, val in type_bounce_info.items():
                if len(val["bounce_ct_list"]) > 0:
                    val["median_bounce"] = median(val["bounce_ct_list"])
                del val["bounce_ct_list"]
            self.report1["type_bounce"] = type_bounce_info
            for key, val in component_bounce_info.items():
                if len(val["bounce_ct_list"]) > 0:
                    val["median_bounce"] = median(val["bounce_ct_list"])
                del val["bounce_ct_list"]
            self.report1["component_bounce"] = component_bounce_info
        except Exception as e:
            self.add_logline("Error creating report 1: " + repr(e))

    # static methods

    @staticmethod
    def handle_assignee(current_assignee, assignee_to_component_count, assignee_to_priority_count,
                        assignee_to_type_count, ticket_type, priority, ticket):
        if current_assignee not in assignee_to_component_count:
            assignee_to_component_count[current_assignee] = {"total_tickets": 0,
                                                             "no_component": 0,
                                                             "assignee": current_assignee}
            assignee_to_priority_count[current_assignee] = {"total_tickets": 0,
                                                            "assignee": current_assignee}
            assignee_to_type_count[current_assignee] = {"total_tickets": 0,
                                                        "assignee": current_assignee}
        assignee_to_component_count[current_assignee]["total_tickets"] += 1
        assignee_to_priority_count[current_assignee]["total_tickets"] += 1
        assignee_to_type_count[current_assignee]["total_tickets"] += 1
        if ticket_type not in assignee_to_type_count[current_assignee]:
            assignee_to_type_count[current_assignee][ticket_type] = 0
        assignee_to_type_count[current_assignee][ticket_type] += 1
        if priority not in assignee_to_priority_count[current_assignee]:
            assignee_to_priority_count[current_assignee][priority] = 0
        assignee_to_priority_count[current_assignee][priority] += 1
        if 'components' not in ticket['fields'] or len(ticket['fields']['components']) == 0:
            assignee_to_component_count[current_assignee]["no_component"] += 1

    @staticmethod
    def handle_top25_data(top_hops, top_bounces, top_assigneect_tickets, assignees,
                          num_bounces, times_with_assignees, summary, ticket):
        heapq.heappush(top_hops,
                       PriorityEntry(len(times_with_assignees),
                                     {"hops": len(times_with_assignees), "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_hops) > 25:
            heapq.heappop(top_hops)
        heapq.heappush(top_assigneect_tickets,
                       PriorityEntry(len(assignees),
                                     {"assignees": len(assignees), "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_assigneect_tickets) > 25:
            heapq.heappop(top_assigneect_tickets)
        heapq.heappush(top_bounces,
                       PriorityEntry(num_bounces,
                                     {"bounces": num_bounces, "ticket_id": ticket["key"],
                                      "summary": summary}))
        if len(top_bounces) > 25:
            heapq.heappop(top_bounces)

    @staticmethod
    def handle_type(type_bounce_info, num_bounces, ticket):
        if "issuetype" not in ticket["fields"]:
            return "UNKNOWN"
        type_name = ticket["fields"]["issuetype"]["name"]
        if type_name not in type_bounce_info:
            type_bounce_info[type_name] = {"total_bounces": 0, "num_tickets": 0, "bounce_ct_list": [],
                                           # first time its both max and min
                                           "max_bounce": num_bounces, "min_bounce": num_bounces}
        type_bounce_info[type_name]["total_bounces"] += num_bounces
        type_bounce_info[type_name]["bounce_ct_list"].append(num_bounces)
        type_bounce_info[type_name]["num_tickets"] += 1
        if type_bounce_info[type_name]["max_bounce"] < num_bounces:
            type_bounce_info[type_name]["max_bounce"] = num_bounces
        elif type_bounce_info[type_name]["min_bounce"] > num_bounces:
            type_bounce_info[type_name]["min_bounce"] = num_bounces
        return type_name

    @staticmethod
    def handle_priority(priority_bounce_info, num_bounces, ticket):
        if "priority" not in ticket["fields"]:
            return "UNKNOWN"
        priority_name = ticket["fields"]["priority"]["name"]
        if priority_name not in priority_bounce_info:
            priority_bounce_info[priority_name] = {"total_bounces": 0, "num_tickets": 0, "bounce_ct_list": [],
                                                   # first time its both max and min
                                                   "max_bounce": num_bounces, "min_bounce": num_bounces}
        priority_bounce_info[priority_name]["total_bounces"] += num_bounces
        priority_bounce_info[priority_name]["bounce_ct_list"].append(num_bounces)
        priority_bounce_info[priority_name]["num_tickets"] += 1
        if priority_bounce_info[priority_name]["max_bounce"] < num_bounces:
            priority_bounce_info[priority_name]["max_bounce"] = num_bounces
        elif priority_bounce_info[priority_name]["min_bounce"] > num_bounces:
            priority_bounce_info[priority_name]["min_bounce"] = num_bounces
        return priority_name

    @staticmethod
    def top_ticket_calculation(top_object, prio, task_type, val, ticket):
        heapq.heappush(top_object["top"],
                       PriorityEntry(val, {"ticket_id": ticket["key"],
                                           "summary": ticket["fields"]["summary"],
                                           "priority": prio,
                                           "type": task_type,
                                           "time": val}))
        top_object["sum"] = top_object["sum"] + val
        top_object["total"] = top_object["total"] + 1
        top_object["list"].append(val)  # this list is used to get the median and max values
        if len(top_object["top"]) > 25:
            heapq.heappop(top_object["top"])

    @staticmethod
    def get_min_max_median(data_list):
        median_val = 0
        min_val = 0
        max_val = 0
        if len(data_list) > 0:
            median_val = median(data_list)
            min_val = min(data_list)
            max_val = max(data_list)
        return min_val, max_val, median_val
