import os
import webbrowser
from threading import Thread
import sys
import pytz
import time
import requests

from datetime import datetime
from flask import Flask, send_from_directory, request, jsonify
from jira_analytics import JANALYTICS

if getattr(sys, 'frozen', False):
    static_parent = sys._MEIPASS  # _MEIPASS folder contains the static data
else:
    static_parent = '.'

app = Flask(__name__, static_folder=os.path.join(static_parent, 'static_folder'))
dirlist = os.listdir(".")

analytics_obj = JANALYTICS()
last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)


# cuz we cant create a dock icon.
def check_or_exit():
    global last_accessed_time
    while True:
        if (datetime.utcnow().replace(tzinfo=pytz.utc) - last_accessed_time).seconds > 86400:
            requests.request("POST", "http://127.0.0.1:5000/api/stop")
            return
        time.sleep(60)


check_thread = Thread(target=check_or_exit, daemon=True)


# Serve React App
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if path != "":
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/jira_auth', methods=['GET', 'POST'])
def get_jiraauth():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        url = ""
        username = ""
        password = ""
        if analytics_obj:
            url, username, password = analytics_obj.get_authinfo()
        return jsonify({"url": url, "username": username, "password": password}), 200
    json_body = request.json
    analytics_obj.set_authinfo(json_body["url"], json_body["username"], json_body["password"])
    jira_status_code, total = analytics_obj.validate_creds()
    if jira_status_code == 400 or total == 0:
        return jsonify({"jira_status": jira_status_code, "issues_total": 0,
                        "error": "No issues found or invalid credentials."}), 400
    return jsonify({"jira_status": jira_status_code,
                    "issues_total": total}), 200


@app.route('/api/statuses', methods=['GET', 'POST'])
def get_jirastatuses():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        report_status, report = analytics_obj.get_bouncereport()
        data = {"status": "complete"}
        if not report_status:
            data = {"status": "incomplete"}
        data.update(analytics_obj.get_statuses())
        return jsonify(data), 200
    json_body = request.json
    analytics_obj.set_statuses(json_body["status"], json_body["ignore"])
    return jsonify({}), 200


@app.route('/api/jql', methods=['POST', 'GET'])
def get_jqlandcount():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        jql, count = analytics_obj.get_jqlandcount()
        return jsonify({"jql": jql, "num_tickets": count}), 200
    json_body = request.json
    if "num_tickets" in json_body:
        analytics_obj.set_jqlandcount(json_body["jql"], json_body["num_tickets"])
    else:
        analytics_obj.set_jqlandcount(json_body["jql"])
    return jsonify({}), 200


@app.route('/api/users', methods=['POST', 'GET'])
def get_users():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        report_status, report = analytics_obj.get_bouncereport()
        data = {"status": "complete"}
        if not report_status:
            data = {"status": "incomplete"}
        data.update(analytics_obj.get_usermap())
        return jsonify(data), 200
    json_body = request.json
    analytics_obj.set_userorg(json_body["user"], json_body["org"])
    return jsonify({}), 200


@app.route('/api/fetch_progress', methods=['GET'])
def get_progress():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    return jsonify(analytics_obj.get_fetchprogress()), 200


@app.route('/api/version', methods=['GET'])
def get_version():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    return jsonify({"version": "v0.1.8"}), 200


@app.route('/api/components', methods=['POST', 'GET'])
def get_components():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        report_status, report = analytics_obj.get_bouncereport()
        data = {"status": "complete"}
        if not report_status:
            data = {"status": "incomplete"}
        data.update(analytics_obj.get_componentmap())
        return jsonify(data), 200
    json_body = request.json
    analytics_obj.set_componentval(json_body["component"], json_body["org"])
    return jsonify({}), 200


@app.route('/api/ticket_details/<ticket_id>', methods=['GET'])
def get_ticketdetails(ticket_id):
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    if request.method == 'GET':
        item = analytics_obj.get_ticketdetails(ticket_id.upper())
        return jsonify(item), 200
    return jsonify({"error": "Ticket does not exist."}), 400


@app.route('/api/stop', methods=['POST'])
def shutdown():
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()
    return jsonify({"ok": True}), 200


@app.route('/api/logs', methods=['GET'])
def get_logs():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    return jsonify({"logs": analytics_obj.get_logs()}), 200


@app.route('/api/bounce_report', methods=['GET'])
def get_bouncereport():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    report_status, report = analytics_obj.get_bouncereport()
    data = {"status": "complete"}
    data.update(report)
    if report_status:
        return jsonify(data), 200
    data["status"] = "incomplete"
    return jsonify(data), 200


@app.route('/api/resolution_report', methods=['GET'])
def get_resolutionreport():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    report_status, report = analytics_obj.get_resolutionreport()
    data = {"status": "complete"}
    data.update(report)
    if report_status:
        return jsonify(data), 200
    data["status"] = "incomplete"
    return jsonify(data), 200


@app.route('/api/reanalyze', methods=['POST'])
def do_reanalyze():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    started = False
    if analytics_obj.is_analyzed():
        started = analytics_obj.redo_analysis()
    return jsonify({"analysis_restarted": started}), 200


@app.route('/api/jira_fetch', methods=['POST'])
def do_jirafetch():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    started = analytics_obj.start_refetchandanalysis()
    return jsonify({"fetch_started": started}), 200


@app.route('/api/time_report', methods=['GET'])
def get_timereport():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    report_status, report = analytics_obj.get_timereport()
    data = {"status": "complete"}
    data.update(report)
    if report_status:
        return jsonify(data), 200
    data["status"] = "incomplete"
    return jsonify(data), 200


@app.route('/api/link_report', methods=['GET'])
def get_linkreport():
    global analytics_obj
    global last_accessed_time
    last_accessed_time = datetime.utcnow().replace(tzinfo=pytz.utc)
    report_status, report = analytics_obj.get_linkreport()
    data = {"status": "complete"}
    data.update(report)
    if report_status:
        return jsonify(data), 200
    data["status"] = "incomplete"
    return jsonify(data), 200


if __name__ == "__main__":
    check_thread.start()
    webbrowser.open_new("http://127.0.0.1:5000")
    app.run()
